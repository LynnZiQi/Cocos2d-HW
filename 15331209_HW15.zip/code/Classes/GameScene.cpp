#include "GameScene.h"
#include "json/rapidjson.h"
#include "json/document.h"
#include "json/writer.h"
#include "json/stringbuffer.h"
#include <regex>
using std::regex;
using std::match_results;
using std::regex_match;
using std::cmatch;
using namespace rapidjson;

USING_NS_CC;

cocos2d::Scene* GameScene::createScene() {
    // 'scene' is an autorelease object
    auto scene = Scene::create();

    // 'layer' is an autorelease object
    auto layer = GameScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

bool GameScene::init() {
    if (!Layer::init())
    {
        return false;
    }

    Size size = Director::getInstance()->getVisibleSize();
    visibleHeight = size.height;
    visibleWidth = size.width;

    score_field = TextField::create("Score", "Arial", 30);
    score_field->setPosition(Size(visibleWidth / 4, visibleHeight / 4 * 3));
    this->addChild(score_field, 2);

    submit_button = Button::create();
    submit_button->setTitleText("Submit");
    submit_button->setTitleFontSize(30);
    submit_button->setPosition(Size(visibleWidth / 4, visibleHeight / 4));
	submit_button->addTouchEventListener(CC_CALLBACK_2(GameScene :: Submit,this));
    this->addChild(submit_button, 2);

	
	

    rank_field = TextField::create("", "Arial", 30);
    rank_field->setPosition(Size(visibleWidth / 4 * 3, visibleHeight / 4 * 3 - 60));
    this->addChild(rank_field, 2);

    rank_button = Button::create();
    rank_button->setTitleText("Rank");
    rank_button->setTitleFontSize(30);
    rank_button->setPosition(Size(visibleWidth / 4 * 3, visibleHeight / 4));
	rank_button->addTouchEventListener(CC_CALLBACK_2(GameScene::rank, this));
	this->addChild(rank_button, 2);

	count_field = TextField::create("10", "Arial", 30);
	count_field->setPosition(Size(visibleWidth / 4 * 3 + 130, visibleHeight / 4));
	this->addChild(count_field, 2);



    return true;
}
void GameScene::Submit(Ref *pSender, Widget::TouchEventType type) {

	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		
		HttpRequest* req = new HttpRequest();

		req->setUrl("localhost:8080/submit");
		//�ύ��Method:POST
		req->setRequestType(HttpRequest::Type::POST);
		//�ص���������������
		req->setResponseCallback(CC_CALLBACK_2(GameScene :: finishSubmit, this));
		vector<string> header;
		header.push_back("Cookie: GAMESESSIONID=" + Global::gameSessionId);
		req->setHeaders(header);
		string score = "score=" + score_field->getString();
		req->setRequestData(score.c_str(), score.size());

		HttpClient::getInstance()->send(req);
		req->release();
		break;

	}

}

void GameScene::finishSubmit(HttpClient* sender, HttpResponse* res) {
	//����ɹ��ύ��Ҫ��������
	if (res->isSucceed())
		rank(this, Widget::TouchEventType::BEGAN);
}

void GameScene::rank(Ref *pSender, Widget::TouchEventType type) {
	switch (type)
	{
	case Widget::TouchEventType::BEGAN:
		string top;
		if (count_field->getString() == "")
			top = "10";
		else 
			top = count_field->getString();
		HttpRequest* req = new HttpRequest();
		req->setUrl(("localhost:8080/rank?top=" + top).c_str());
		//���ط�����Method:GET
		req->setRequestType(HttpRequest::Type::GET);
		//�ص���������ʾ����
		req->setResponseCallback(CC_CALLBACK_2(GameScene::rankShow, this));
		vector<string> header;
		header.push_back("Cookie: GAMESESSIONID=" + Global::gameSessionId);
		req->setHeaders(header);
		HttpClient::getInstance()->send(req);
		req->release();
	}

}

void GameScene::rankShow(HttpClient* sender, HttpResponse* res) {

	if (res->isSucceed()) {
		string resData(res->getResponseData()->begin(), res->getResponseData()->end());
		rapidjson::Document json;
		json.Parse(resData.c_str());
		if (json["result"].GetBool()) {
			string result = json["info"].GetString();
			result.erase(0, 1);
			for (int i = 0; i < result.length(); ++i) {
				if (result[i] == '|')
					result[i] = '\n';  //������ʾ
			}
			rank_field->setString(result);
			//rank_field->setString("!!!!");
		}
		//string rankRes = json["info"].GetString();
		//rank_field->setString(rankRes);
		//rank_field->setString("????");
	}
}