﻿#include "LoginScene.h"
#include "cocostudio/CocoStudio.h"
#include "json/rapidjson.h"
#include "json/document.h"
#include "json/writer.h"
#include "json/stringbuffer.h"
#include "Global.h"
#include "GameScene.h"
#include <regex>
using std::to_string;
using std::regex;
using std::match_results;
using std::regex_match;
using std::cmatch;
using namespace rapidjson;
USING_NS_CC;
#pragma execution_character_set("utf-8")
using namespace cocostudio::timeline;

#include "json/document.h"
#include "json/writer.h"
#include "json/stringbuffer.h"
using namespace  rapidjson;

Scene* LoginScene::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = LoginScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}





// on "init" you need to initialize your instance
bool LoginScene::init()
{
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }

    Size size = Director::getInstance()->getVisibleSize();
    visibleHeight = size.height;
    visibleWidth = size.width;

    textField = TextField::create("Player Name", "Arial", 30);
    textField->setPosition(Size(visibleWidth / 2, visibleHeight / 4 * 3));
    this->addChild(textField, 2);

    auto button = Button::create();
    button->setTitleText("Login");
    button->setTitleFontSize(30);
    button->setPosition(Size(visibleWidth / 2, visibleHeight / 2));
    

	//为按钮添加触摸事件监听  
	button -> addTouchEventListener(CC_CALLBACK_2(LoginScene::Login, this));
	this->addChild(button, 2);
    return true;
}

void LoginScene::Login(Ref *pSender, Widget::TouchEventType type) {
	switch (type)
	{
		case Widget::TouchEventType::BEGAN:
		if (textField->getString() != "") {
			HttpRequest* req = new HttpRequest();
			//登录，Method:POST
			req->setRequestType(HttpRequest::Type::POST);
			req->setUrl("localhost:8080/login");
			string user = "username=" + textField->getString();
			req->setRequestData(user.c_str(), user.size());
			//回调函数，getSessionId和场景转换
			req->setResponseCallback(CC_CALLBACK_2(LoginScene::onLogin, this));
			HttpClient::getInstance()->send(req);
			req->release();
		}
		break;
		default:
			break;
	}
}

void LoginScene::onLogin(HttpClient * sender, HttpResponse * res) {
	if (res->isSucceed()) {
		string resHeader(res->getResponseHeader()->begin(), res->getResponseHeader()->end());
		//set gameSeesionId
		Global::gameSessionId = Global::getSessionIdFromHeader(resHeader);
		//页面跳转（场景转换）
		Director::getInstance()->replaceScene(TransitionCrossFade::create(0.2f, GameScene::createScene()));
	}

}