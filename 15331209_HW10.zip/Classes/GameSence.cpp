﻿#include "GameSence.h"

USING_NS_CC;

Scene* GameSence::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = GameSence::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
bool GameSence::init()
{

	if (!Layer::init())
	{
		return false;
	}
	srand((unsigned)time(NULL));
	//add touch listener
	EventListenerTouchOneByOne* listener = EventListenerTouchOneByOne::create();
	listener->setSwallowTouches(true);
	listener->onTouchBegan = CC_CALLBACK_2(GameSence::onTouchBegan, this);
	Director::getInstance()->getEventDispatcher()->addEventListenerWithSceneGraphPriority(listener, this);

	
	Size visibleSize = Director::getInstance()->getVisibleSize();
	Vec2 origin = Director::getInstance()->getVisibleOrigin();
	Size mywinsize = Director::getInstance()->getWinSize();

	//background
	winw = mywinsize.width; //获取屏幕宽度  
	winh = mywinsize.height;//获取屏幕高度  
	auto background = Sprite::create("level-background-0.jpg");
	float spx = background->getTextureRect().getMaxX();
	float spy = background->getTextureRect().getMaxY();
	background->setScaleX(winw / spx);
	background->setScaleY(winw / spy);
	// position the sprite on the center of the screen
	background->setPosition(Vec2(origin.x + visibleSize.width / 2, origin.y + visibleSize.height / 2));
	// add the sprite as a child to this layer
	this->addChild(background, 0);
	
	//stone
	stoneLayer = Layer::create();
	stoneLayer->ignoreAnchorPointForPosition(false);
	stoneLayer->setAnchorPoint(Vec2::ZERO);  //锚点设置
	stoneLayer->setPosition(Vec2::ZERO);
	//添加石头
	stone = Sprite::create("stone.png");
	stone->setPosition(Vec2(560, 480));
	stoneLayer->addChild(stone);
	this->addChild(stoneLayer, 1);

	//menuItem
	auto Shoot = Label::createWithTTF("Shoot", "fonts/Marker Felt.ttf", 50);
	auto ShootItem = MenuItemLabel::create(Shoot, CC_CALLBACK_1(GameSence::shootMenuCallback, this));
	Menu* shoot = Menu::create(ShootItem, NULL);
	shoot->setPosition(Vec2(700, 480));
	stoneLayer->addChild(shoot);

	//mouse
	mouseLayer = Layer::create();
	mouseLayer->ignoreAnchorPointForPosition(false);
	mouseLayer->setAnchorPoint(Vec2(0, 0));  //锚点设置
	mouseLayer->setPosition(Vec2(0, winh / 2));
	this->addChild(mouseLayer, 1);

	//mouse's action
	mouse = Sprite::createWithSpriteFrameName("gem-mouse-0.png");
	Animate* mouseAnimate = Animate::create(AnimationCache::getInstance()->getAnimation("mouseAnimation"));
	mouse->runAction(RepeatForever::create(mouseAnimate)); //重复设置图像，相当于动画效果
	mouse->setPosition(winw / 2, 0);
	toPos = Vec2(winw / 2, 0);    //要求的位置
	mouseLayer->addChild(mouse, 2);  

	return true;
}

bool GameSence::onTouchBegan(Touch *touch, Event *unused_event) {

	auto location = touch->getLocation();  //获得点击的坐标
	fromPos = mouse->getPosition();
	if (fromPos == toPos) { //一次只能出现一块奶酪，否则出错
		if (location.y < 450) {//石头下方
			toPos = Vec2((int)location.x, (int)(location.y - winh / 2));
			//cheese
			cheese = Sprite::create("cheese.png");
			cheese->setPosition(toPos);
			mouseLayer->addChild(cheese);

			//奶酪淡出
			auto move = MoveTo::create(1.0, toPos);
			mouse->runAction(move);
			cheese->runAction(Sequence::create(ScaleTo::create(2.0, 1.0), FadeOut::create(1.0), nullptr));
		}
	}
	return true;
}

void GameSence::shootMenuCallback(Ref * pSender) {
	fromPos = mouse->getPosition();
	if (fromPos == toPos) {
		auto shootstone = Sprite::createWithSpriteFrameName("stone-0.png");
		Animate* stoneAnimate = Animate::create(AnimationCache::getInstance()->getAnimation("stoneAnimation"));
		shootstone->runAction(RepeatForever::create(stoneAnimate));
		shootstone->setPosition(stone->getPosition());
		this->addChild(shootstone, 1);
		auto seq = Sequence::create(MoveTo::create(1.0, Vec2(fromPos.x, fromPos.y + winh / 2)), FadeOut::create(0.5), nullptr);
		shootstone->runAction(seq);

		auto diamond = Sprite::create("diamond.png");
		diamond->setPosition(fromPos);
		mouseLayer->addChild(diamond, 1);
		toPos.x = (int)(CCRANDOM_0_1() * 960);
		toPos.y = (int)(CCRANDOM_0_1() * 480 - winh / 2);
		auto mousemoveto = MoveTo::create(1.5, toPos);
		mouse->runAction(mousemoveto);
	}
}